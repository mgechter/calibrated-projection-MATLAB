[TBA: State that the dataset is taken from KT. Provide further details.]
