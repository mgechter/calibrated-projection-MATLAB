If CVX is preferrred to CVXGEN due to problem size, then visit http://cvxr.com/cvx/ and download the most recent version of CVX.
